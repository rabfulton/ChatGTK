#!/usr/bin/env python3
import gi
import threading
import openai

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib

class OpenAIGTKClient(Gtk.Window):
    def __init__(self):
        super().__init__(title="OpenAI GTK Client")
        self.set_default_size(600, 500)

        # Main container
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        vbox.set_margin_top(10)
        vbox.set_margin_bottom(10)
        vbox.set_margin_start(10)
        vbox.set_margin_end(10)
        self.add(vbox)

        # API Key input
        hbox_api = Gtk.Box(spacing=6)
        lbl_api = Gtk.Label(label="API Key:")
        self.entry_api = Gtk.Entry()
        self.entry_api.set_visibility(False)  # Hide API key text
        hbox_api.pack_start(lbl_api, False, False, 0)
        hbox_api.pack_start(self.entry_api, True, True, 0)
        vbox.pack_start(hbox_api, False, False, 0)

        # Model selection drop-down
        hbox_model = Gtk.Box(spacing=6)
        lbl_model = Gtk.Label(label="Model:")
        self.combo_model = Gtk.ComboBoxText()
        # Add available models
        self.combo_model.append_text("gpt-3.5-turbo")
        self.combo_model.append_text("gpt-4")
        self.combo_model.set_active(0)
        hbox_model.pack_start(lbl_model, False, False, 0)
        hbox_model.pack_start(self.combo_model, True, True, 0)
        vbox.pack_start(hbox_model, False, False, 0)

        # Text area for conversation (read-only)
        self.textview = Gtk.TextView()
        self.textview.set_editable(False)
        self.textview.set_wrap_mode(Gtk.WrapMode.WORD)
        self.textbuffer = self.textview.get_buffer()
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_vexpand(True)
        scrolled_window.add(self.textview)
        vbox.pack_start(scrolled_window, True, True, 0)

        # Question input and send button
        hbox_input = Gtk.Box(spacing=6)
        self.entry_question = Gtk.Entry()
        self.entry_question.set_placeholder_text("Enter your question here...")
        self.entry_question.connect("activate", self.on_submit)  # Submit on Enter key
        btn_send = Gtk.Button(label="Send")
        btn_send.connect("clicked", self.on_submit)
        hbox_input.pack_start(self.entry_question, True, True, 0)
        hbox_input.pack_start(btn_send, False, False, 0)
        vbox.pack_start(hbox_input, False, False, 0)

        # Voice input (placeholder for bonus integration)
        btn_voice = Gtk.Button(label="Voice Input")
        btn_voice.connect("clicked", self.on_voice_input)
        vbox.pack_start(btn_voice, False, False, 0)

    def append_text(self, text):
        """Append text to the conversation area."""
        end_iter = self.textbuffer.get_end_iter()
        self.textbuffer.insert(end_iter, text)
        # Optionally, scroll to the bottom automatically

    def on_submit(self, widget):
        question = self.entry_question.get_text().strip()
        if not question:
            return

        api_key = self.entry_api.get_text().strip()
        if not api_key:
            self.append_text("** Error: Please enter your API key. **\n")
            return

        model = self.combo_model.get_active_text()
        self.append_text(f"**You:** {question}\n")
        self.entry_question.set_text("")

        # Call OpenAI API in a separate thread so the UI doesn’t freeze
        threading.Thread(target=self.call_openai_api, args=(api_key, model, question), daemon=True).start()

    def call_openai_api(self, api_key, model, question):
        openai.api_key = api_key
        try:
            # For the new API it's recommended to include a system message.
            messages = [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": question}
            ]
            response = openai.resources.chat.Completions.n.create(
                model=model,
                messages=messages,
                temperature=0.7,
            )
            # Access the response via dictionary keys
            answer = response["choices"][0]["message"]["content"]

            # Basic formatting: wrap code blocks in a visual marker
            if "```" in answer:
                answer = answer.replace("```", "\n--- Code Block ---\n")
            # Update UI from the main thread
            GLib.idle_add(self.append_text, f"**AI:** {answer}\n")
        except Exception as e:
            GLib.idle_add(self.append_text, f"** Error: {str(e)} **\n")

    def on_voice_input(self, widget):
        self.append_text("Voice input not implemented yet.\n")
        # For a bonus feature, integrate a speech-to-text library here.
        # For instance, you might use the SpeechRecognition library:
        #   import speech_recognition as sr
        #   ... initialize recognizer, capture audio, and convert to text.
        # Then call self.entry_question.set_text(recognized_text) and maybe auto-submit.

def main():
    win = OpenAIGTKClient()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()
